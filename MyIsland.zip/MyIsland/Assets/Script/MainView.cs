﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainView : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void OnClickSettingBtn(){
		gameObject.SetActive(true);
	}
	public void OnClickInventoryBtn(){
		gameObject.SetActive (true);
	}
}
